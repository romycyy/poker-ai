# Additional Resources

## Discord

Join the [Discord server](https://discord.gg/J9be7vVt5F) for announcements and discussion with other participants.

## Lecture Slides

Slides and resources can be found [here](https://github.com/cmu-dsc/poker-slides).

## Papers

- [Game Theory-Based Opponent Modeling in Large Imperfect Information Games](https://www.cs.cmu.edu/afs/cs/Web/People/sandholm/opponentModeling.aamas11.pdf)
